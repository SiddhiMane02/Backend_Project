package frontendPackage;

import java.util.Scanner;

import backendPackage.AddNewMenuFunctionality;
import backendPackage.ListOfMenuFunctionality;
import backendPackage.PlaceOrderFunctionality;
import backendPackage.ProfitPerDayFunctionality;
import backendPackage.UpdateMenuFunctionality;
import globalPackage.GlobalVariables;

public class FlamesManagementMain {
	
	GlobalVariables globalVariables=new GlobalVariables();
	AddNewMenuFunctionality addNewMenuFunctionality=new AddNewMenuFunctionality();
	UpdateMenuFunctionality updateMenuFunctionality=new UpdateMenuFunctionality();
	PlaceOrderFunctionality placeOrderFunctionality=new PlaceOrderFunctionality();
	ProfitPerDayFunctionality profitPerDayFunctionality=new ProfitPerDayFunctionality();
	ListOfMenuFunctionality listOfMenuFunctionality=new ListOfMenuFunctionality();
	
	void MainScreen()
	{
		do {
			System.out.println("\n\t*****FLAMES MANAGEMENT SYSTEM*****\n"
					+ "1. ADD NEW MENU \n"+"2. UPDATE MENU \n"+"3. PLACE ORDER\n"+"4. PROFIT PER DAY\n"+"5. LIST OF MENU \n"+"6. EXIT\n");
			
			globalVariables.scan=new Scanner(System.in);
			switch(globalVariables.scan.nextInt()) {
			case 1:
				addNewMenuFunctionality.addNewMenu();
				break;
			case 2:
				updateMenuFunctionality.updateMenu();
				break;
			case 3:
				placeOrderFunctionality.Placeorder();
				break;
			case 4:
				profitPerDayFunctionality.profitPerday();
				break;
			case 5:
				listOfMenuFunctionality.Listofmenu();
				break;
			case 6:
				System.out.println("EXIT");
				System.exit(1);
				break;
				
			}
		}while(true);
	}
	public static void main(String[] args) {
		FlamesManagementMain flamesManagementMain=new FlamesManagementMain();
		flamesManagementMain.MainScreen();

	}

}
