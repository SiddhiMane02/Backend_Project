package frontendPackage;

public class Billfronted {
	
	public void billtop() {
	System.out.println("\n******************************************************************************");
	System.out.println("______________________________________________________________________________");
	System.out.println("\t \t \t \tFLAMES\t \t \t \t");
	System.out.println("\t \t \t ignite the flame\t \t \t");
	System.out.println("\t Shop No.15,Nandaprem Shopping Center,Ram Mandir Road,\t");
	System.out.println("\t \t \tVileparle (E),Mumbai-57\t \t \t");
	System.out.println("\t \t \t  Phone:7718886691\t \t \t");
	System.out.println("______________________________________________________________________________");
	
	}
	public void billend() {
		System.out.println("******************************************************************************");
	}

}
