package globalPackage;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.protocol.Resultset;

public class GlobalVariables {
	
	
	
	public Scanner scan;
	public PreparedStatement ps;
	public ResultSet rs;
	public FileWriter fw;
	
	
	public Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/mybasicdb","root","MySql@123");
		return con;
		
	}

}
