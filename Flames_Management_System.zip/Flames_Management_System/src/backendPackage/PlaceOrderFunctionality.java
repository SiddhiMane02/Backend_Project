package backendPackage;


import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Scanner;
import frontendPackage.Billfronted;
import globalPackage.GlobalVariables;

public class PlaceOrderFunctionality {
	GlobalVariables globalVariables=new GlobalVariables();
	AddNewMenuPojo addNewMenuPojo=new AddNewMenuPojo();
	Billfronted billfronted=new Billfronted();
	 LocalDateTime ldt=LocalDateTime.now();
	
	public void Placeorder() {
		int billno=1;
		try {
			globalVariables.fw=new FileWriter("/C:/Users/siddh/eclipse-workspace/Flames_Management_System/Flames_management_files/FlamesBill.txt");
			globalVariables.fw.append("\n******************************************************************************\n");
			globalVariables.fw.append("______________________________________________________________________________\n");
			globalVariables.fw.append("\t \t \t \tFLAMES\t \t \t \t \n");
			globalVariables.fw.append("\t \t \t ignite the flame\t \t \t \n");
			globalVariables.fw.append("\t Shop No.15,Nandaprem Shopping Center,Ram Mandir Road,\t \n");
			globalVariables.fw.append("\t \t \tVileparle (E),Mumbai-57\t \t \t \n");
			globalVariables.fw.append("\t \t \t  Phone:7718886691\t \t \t \n");
			globalVariables.fw.append("______________________________________________________________________________\n");
		    globalVariables.fw.append("\t \tBill No:"+billno+"\t \t \n");
			globalVariables.fw.append("Date: "+LocalDate.now()+"\t Time: "+LocalTime.now()+"\n");
			globalVariables.fw.append("Menu Name\t            Qty \t Price \t \t TotalPrice\n");
			
			globalVariables.scan = new Scanner(System.in);
			Connection con=globalVariables.getConnection();
			int GrandTotal=0;
			int Totalprice=0;
			int check;
			
			do {
			System.out.println("ENTER YOUR MENU:");
			addNewMenuPojo.setName(globalVariables.scan.nextLine().toLowerCase());
			globalVariables.ps=con.prepareStatement("select * from Flames_Menu_table where menu_name=? ");
			globalVariables.ps.setString(1,addNewMenuPojo.getName());
			globalVariables.rs=globalVariables.ps.executeQuery();
			System.out.println("ENTER QUANTITY:");
			addNewMenuPojo.setQty(globalVariables.scan.nextInt());
			
			while(globalVariables.rs.next())
			{
			System.out.println("price:" +globalVariables.rs.getInt(2));
			addNewMenuPojo.setPrice(globalVariables.rs.getInt(2));
			Totalprice=addNewMenuPojo.getQty() * globalVariables.rs.getInt(2);
			System.out.println("Totalprice:"+Totalprice);
			GrandTotal=GrandTotal+Totalprice;
			globalVariables.fw.append(addNewMenuPojo.getName()+"\t"+addNewMenuPojo.getQty()+"\t \t"+addNewMenuPojo.getPrice()+"\t"+Totalprice+"\n");
			}
			
			System.out.println("DO YOU WANT TO ORDER MORE MENU?(IF YES ENTER 1/NO ENTER 0)");
			check=globalVariables.scan.nextInt();
			globalVariables.scan.nextLine();
			if(check==0)
			{ 
				globalVariables.ps=con.prepareStatement("insert into Flames_Profit_Perday_table values(?,?)");
				globalVariables.ps.setDate(1,Date.valueOf(LocalDate.now()));
				globalVariables.ps.setInt(2,GrandTotal);
				globalVariables.ps.executeUpdate();
				globalVariables.fw.append("------------------------------------------------------------------------------\n");
				globalVariables.fw.append("\n Grand total:-                                                 "+GrandTotal+"\n");
				globalVariables.fw.append("******************************************************************************\n");
				System.out.println("GRAND TOTAL:"+GrandTotal);
				System.out.println("bill created!!!");
				
			}
		    
			} while (check != 0);
	
			
			globalVariables.fw.close();
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	
}


	
}
