package backendPackage;

import java.sql.Connection;
import java.sql.Date;

import java.sql.SQLException;
import java.util.Scanner;

import globalPackage.GlobalVariables;

public class ProfitPerDayFunctionality {
	GlobalVariables globalVariables=new GlobalVariables();
	AddNewMenuPojo addNewMenuPojo=new AddNewMenuPojo();
	public void profitPerday() {
		globalVariables.scan=new Scanner(System.in);
		System.out.println("ENTER DATE(YYYY-MM-DD) TO SEE PROFIT:");
		addNewMenuPojo.setDateInput(globalVariables.scan.next());
		try {
			Connection con=globalVariables.getConnection();
			//String date;
			//date=globalVariables.scan.next();
			globalVariables.ps=con.prepareStatement("select SUM(grand_total) as PROFIT from Flames_Profit_Perday_table where Day_Date=?");
			globalVariables.ps.setDate(1,Date.valueOf(addNewMenuPojo.getDateInput()));
			globalVariables.rs=globalVariables.ps.executeQuery();
			while(globalVariables.rs.next())
			{
				//System.out.println("date:"+globalVariables.rs.getDate(1)+" :  grandtotal: "+globalVariables.rs.getInt(2));
				System.out.println(("PROFIT: "+globalVariables.rs.getInt(1)));

			
			}
		} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}//SUM(grand_total)as PROFIT  where Day_Date=2023-12-31

}
