package backendPackage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


import globalPackage.GlobalVariables;

public class ListOfMenuFunctionality {


	GlobalVariables globalVariables=new GlobalVariables();
	AddNewMenuPojo addNewMenuPojo=new AddNewMenuPojo();
	public void Listofmenu() {
		try {
			Connection con=globalVariables.getConnection();
			globalVariables.ps=con.prepareStatement("select * from Flames_Menu_table");
			ResultSet rs=globalVariables.ps.executeQuery();
			System.out.println("                                     MENU LIST                                    ");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
			System.out.println("\tMENU NAME\t \t \t \t \t \t \t \t \t \t \t \t \t \tMENU PRICE ");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			int count=0;
			while(rs.next())
			{
				count++;
				//System.out.println("MENU NAME :"+rs.getString(1)+"\t"+"MENU PRICE :"+rs.getString(2));~
				
				System.out.println(count+"\t"+rs.getString(1)+"\t \t \t \t \t \t \t \t \t \t \t \t \t"+rs.getString(2));
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
