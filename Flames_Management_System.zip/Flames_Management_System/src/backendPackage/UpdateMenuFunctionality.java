package backendPackage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import globalPackage.GlobalVariables;

public class UpdateMenuFunctionality {
	
	
	GlobalVariables globalVariables=new GlobalVariables();
	AddNewMenuPojo addNewMenuPojo=new AddNewMenuPojo();
	
	public void updateMenu() {
		globalVariables.scan=new Scanner(System.in);
		System.out.println("ENTER MENU NAME TO UPDATE:");
		addNewMenuPojo.setName(globalVariables.scan.nextLine().toLowerCase());
		
		try {
			Connection con = globalVariables.getConnection();
			globalVariables.ps=con.prepareStatement("select * from Flames_Menu_table where menu_name=?");
			globalVariables.ps.setString(1,addNewMenuPojo.getName());
			ResultSet rs=globalVariables.ps.executeQuery();
			if(rs.next()!=false)
			{
				addNewMenuPojo.setPrice(rs.getInt(2));
				System.out.println("Old Price:"+rs.getInt(2));
			

			System.out.println("\nENTER NEW PRICE:");
			addNewMenuPojo.setPrice(globalVariables.scan.nextInt());
			globalVariables.ps=con.prepareCall("update Flames_Menu_table set menu_price=? where menu_name=?");
			
			globalVariables.ps.setInt(1,addNewMenuPojo.getPrice());
			globalVariables.ps.setString(2,addNewMenuPojo.getName());
			int row=globalVariables.ps.executeUpdate();
			System.out.println(row+" MENU HAS BEEN UPDATED!");
			}
			else if (rs.next()==false) {
				System.out.println("NO SUCH MENU IN LIST ");
			}

			
		} catch (ClassNotFoundException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
