package backendPackage;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.InputMismatchException;
import java.util.Scanner;

import globalPackage.GlobalVariables;

public class AddNewMenuFunctionality {
	
	GlobalVariables globalVariables=new GlobalVariables();
	AddNewMenuPojo addNewMenuPojo=new AddNewMenuPojo();
	
	public void addNewMenu() {
		globalVariables.scan=new Scanner(System.in);
		System.out.println("ENTER FOLLOWING DETAILS TO ADD NEW MENU");
		System.out.println("ENTER MENU NAME:");
		addNewMenuPojo.setName(globalVariables.scan.nextLine().toLowerCase());
		System.out.println("ENTER PRICE:");
		addNewMenuPojo.setPrice(globalVariables.scan.nextInt());
		
		
		
		try {
			Connection con=globalVariables.getConnection();
			globalVariables.ps=con.prepareStatement("insert into Flames_Menu_table values(?,?)");

			globalVariables.ps.setString(1,addNewMenuPojo.getName());
			globalVariables.ps.setInt(2,addNewMenuPojo.getPrice());
			//int row=globalVariables.ps.executeUpdate();
			try {
			System.out.println(globalVariables.ps.executeUpdate()+" MENU IS ADDED SUCCESSFULLY!");
			}catch(SQLIntegrityConstraintViolationException e)
			{
				System.out.println("THIS MENU IS ALLREADY THERE IN LIST!");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		
	}
	

}
