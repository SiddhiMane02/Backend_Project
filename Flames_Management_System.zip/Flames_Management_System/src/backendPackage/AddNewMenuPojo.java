package backendPackage;

import java.time.LocalDate;

public class AddNewMenuPojo {
	
  private String name;
  private int price;
  private int qty;
  private String date;
 
  
  public String getName() {
	  return name;
  }
  
  public void setName(String name) {
	  this.name=name;
  }
  
  public int getPrice() {
	  return price;
  }
  
  public void setPrice(int price) {
	  this.price=price;
  }
  
  public int getQty() {
	  return qty;
  }
  
  public void setQty(int qty) {
	  this.qty=qty;
  }
  
  public String setDateInput(String date) {
	  return this.date=date;
	  
  }
  public String getDateInput() {
	return date;
	  
  }
   
  
}
